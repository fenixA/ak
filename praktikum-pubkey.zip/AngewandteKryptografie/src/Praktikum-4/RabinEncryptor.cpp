/*
 * RabinEncryptor.cpp
 */

#include "RabinEncryptor.h"

RabinEncryptor::RabinEncryptor(const Integer& n, const Integer& padding) {
}

RabinEncryptor::~RabinEncryptor() {
}

// #compute()
bool RabinEncryptor::compute(const Integer& x, Integer& y) {
  return false;
}

// #compute2()
bool RabinEncryptor::compute2(const Integer& x, Integer& y) {
  return false;
}
