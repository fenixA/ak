/*
 * RSAEncryptor.cpp
 */

#include "PublicKeyAlgorithmBox.h"
#include "RSAEncryptor.h"

RSAEncryptor::RSAEncryptor(const Integer& n, const Integer& e) {
}

RSAEncryptor::~RSAEncryptor() {}

bool RSAEncryptor::compute(const Integer& x, Integer& y) const {
  return false;
}
